protocol = 1;
name = "Roots Drone Feed";
picture = "";
logo = "";
logoSmall = "";
actionName = "GitHub";
action = "https://github.com/roots";

timestamp = 638997752090000000;
